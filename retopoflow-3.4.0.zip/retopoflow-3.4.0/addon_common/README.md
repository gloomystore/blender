# addon_common

This repo contains the CookieCutter Blender add-on framework.

## Example Add-on

As an example add-on, see the [ExtruCut](https://github.com/CGCookie/ExtruCut) project.

## resources

- Blender Conference 2018 workshop [slides](https://gfx.cse.taylor.edu/courses/bcon18/index.md.html?scale) and [presentation](https://www.youtube.com/watch?v=YSHdSNhMO1c)
